MadeInMagius 1.1.1 / 受检 APK 0.2.1 客户端比对复现
2026-10-17

一、下载和准备
从本网站“资源比对与证据记录”下载历史 MadeInMagius 1.1.1 APK 与本工具包。历史 APK 仅作为比对基准，不替换玩家当前使用版本，也无需安装到手机。
受检 magireco-local-0.2.1.apk 由复核者自行取得，本工具包不重新分发受检 APK。
工具：Python 3.11 或以上（原核验使用 3.14）、Java（原核验使用 JDK 25.0.4）、apktool 3.0.3。
Python：https://www.python.org/downloads/
Java：https://jdk.java.net/
apktool 官方下载：https://github.com/iBotPeaches/Apktool/releases/download/v3.0.3/apktool_3.0.3.jar

二、文件身份（必须一致）
我方 APK：103,821,876 字节
SHA-256：60031daf95e42448f4ddb2d80a1b0b08f007734a488e0b7318a4decc20a02815
受检 APK：71,067,750 字节
SHA-256：feeeac4902499e835871a4558c1ce3eda0ec530f111728322cc0ec376e69bc8e
apktool_3.0.3.jar：15,478,013 字节
SHA-256：dbf930b076c6b9be08d57c449cacefc3bdd6b71ebd59b3066fc0e1f5b14f9423
我方 1.1.1 对应源码包 SHA-256：ad9899a1b2af0ac1c45a4f316cf655dcd3c94293814b12e6aeeb375c2641b513
源码提交：8fd64b358694845c4a85debfd67b15a9d3b566ac；历史构建运行：37211824965。

三、运行（Windows PowerShell 示例）
解压工具包，将两份 APK 和 apktool_3.0.3.jar 放到工具目录，按实际文件名调整参数。

py -3.14 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe compare_apks.py --ours .\MadeInMagius-1.1.1.apk --candidate .\magireco-local-0.2.1.apk --apktool .\apktool_3.0.3.jar --out .\results

其他 Python 3.11+ 版本可将 py -3.14 换为对应版本。Java 未加入 PATH 时，添加 --java "Java安装目录\bin\java.exe"。
Linux/macOS 可用 python3 创建虚拟环境并使用 .venv/bin/python；其余参数相同。
results 必须是新的目录；复跑时使用 --out .\results-2。脚本不覆盖输入，不安装或运行 APK，不连接游戏服务器。
不包括下载工具在内，比对过程无需联网。输出通常需数分钟和数百 MiB 至数 GiB 空间，取决于 Java 与设备性能。

四、检查结果
命令退出码 0，末行 EXPECTED_COUNTS_MATCH=True，表示本次复现命中全部已冻结计数。
退出码 1 是输入或执行错误；退出码 2 表示完成比较但计数与冻结结果不同，应查看原始输出，不强行改为一致。

预期补丁范围 io/kamihama/magianative/**/*.smali：
我方 357；受检方 358；同名 352；并集 363。
逐文件 SHA-256 完全一致 196；同名但修改 156，其中按行相似度至少 90% 的 110。
仅受检方 6；仅我方 5。
共同 assets 392；其中字节一致 332；其中同路径也命中 Totentanz 原版指纹 309。

summary.json：完整计数与输入身份。
smali-files.csv：363 行文件级关系、双方哈希与文本相似度。
changed-classes.json：修改类的行数与差异区间。
CNWebProxy.smali.diff.txt、CNPaths.smali.diff.txt、CNBuildConfig.smali.diff.txt：三个具体例子的逐行差异。
native-comparison.json：每个架构的字节差异、动态符号和已定义全局／弱导出分别统计。
ours-native.json、candidate-native.json：符号名称清单，保留导入与导出的区分。
assets-comparison.json：assets 同名、一致与原版基线命中的路径清单。
execution.json、decode-*.log：实际命令、工具输出、退出码。
verification.json：输入未改写及冻结计数校验。

五、统一方法
双方都使用同一份 apktool 3.0.3：d -r --no-assets -j 4；默认保留调试信息。
仅统计补丁命名空间，禁止把游戏原版或第三方通用库混入补丁类数量。
文本相似度为 difflib.SequenceMatcher(None, 我方.splitlines(), 受检方.splitlines(), autojunk=False).ratio()。
动态符号表的非空名称包含导入；实际导出另以“非 SHN_UNDEF、STB_GLOBAL/STB_WEAK”计算。
APK 文件名可以改，但内容 SHA-256 必须与上述一致。此工具拒绝混入其他版本。
附带 totentanz-members.json 是冻结原版 APK 的路径、大小与 SHA-256 索引，不包含游戏文件。原版 APK SHA-256 记录在索引中。

六、范围
本工具复现 2026-10-17 的客户端复核，不把报告中的历史资源层 10/17 包、72 条登记命中或 4,926 项资源匹配伪装成本次脚本结果。
资源层继续使用原报告冻结的 2026-10-12 索引及其方法：整包以大小和全部 16 MiB 分块 MD5 对比，资源单文件以 SHA-256 对比，官方、第三方及项目处理来源分开判断。
公开网页的匿名说明与本地详细差异分开；本地复核会看到 APK 本身已有的应用包名、域名等字面值。
