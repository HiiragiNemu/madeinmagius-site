"""Reproduce the frozen 1.1.1 / 0.2.1 client comparison without installing either APK."""
from pathlib import Path
import argparse, csv, difflib, hashlib, io, json, platform, subprocess, sys, zipfile
from elftools.elf.elffile import ELFFile

HERE=Path(__file__).resolve().parent
OURS_SHA='60031daf95e42448f4ddb2d80a1b0b08f007734a488e0b7318a4decc20a02815'
CANDIDATE_SHA='feeeac4902499e835871a4558c1ce3eda0ec530f111728322cc0ec376e69bc8e'
APKTOOL_SHA='dbf930b076c6b9be08d57c449cacefc3bdd6b71ebd59b3066fc0e1f5b14f9423'
PREFIX='io/kamihama/magianative/'

def sha(data): return hashlib.sha256(data).hexdigest()
def file_sha(p):
 with p.open('rb') as f: return hashlib.file_digest(f,'sha256').hexdigest()
def save(p,v): p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf8')
def smali(root):
 result={}
 for p in sorted(root.glob('smali*/'+PREFIX+'**/*.smali')):
  key=p.as_posix().split('/'+PREFIX,1)[1]
  if key in result: raise RuntimeError('Duplicate scoped class: '+key)
  result[key]=p.read_bytes()
 if not result: raise RuntimeError('No scoped classes decoded')
 return result
def members(p):
 result={}; native={}
 with zipfile.ZipFile(p) as z:
  for entry in z.infolist():
   if entry.is_dir(): continue
   name=entry.filename
   if name in result: raise RuntimeError('Duplicate APK member: '+name)
   data=z.read(entry);result[name]={'bytes':len(data),'sha256':sha(data)}
   if name.startswith('lib/') and name.endswith('.so'):
    e=ELFFile(io.BytesIO(data));ds=e.get_section_by_name('.dynsym')
    symbols=list(ds.iter_symbols()) if ds else []
    names=sorted({s.name for s in symbols if s.name})
    exports=sorted({s.name for s in symbols if s.name and s['st_shndx']!='SHN_UNDEF' and s['st_info']['bind'] in ('STB_GLOBAL','STB_WEAK')})
    native[name]={'bytes':len(data),'sha256':sha(data),'all_dynsym_names':names,'defined_global_weak_exports':exports,'has_symtab':e.get_section_by_name('.symtab') is not None}
 return result,native

def main():
 ap=argparse.ArgumentParser(description=__doc__)
 ap.add_argument('--ours',type=Path,required=True)
 ap.add_argument('--candidate',type=Path,required=True)
 ap.add_argument('--apktool',type=Path,required=True)
 ap.add_argument('--java',default='java')
 ap.add_argument('--out',type=Path,required=True,help='New output directory; existing directories are not overwritten')
 args=ap.parse_args()
 if sys.version_info<(3,11): raise RuntimeError('Python 3.11+ required; original replay used Python 3.14')
 paths={'ours':args.ours.resolve(),'candidate':args.candidate.resolve(),'apktool':args.apktool.resolve()}
 expected={'ours':OURS_SHA,'candidate':CANDIDATE_SHA,'apktool':APKTOOL_SHA}
 inputs={}
 for k,p in paths.items():
  h=file_sha(p)
  if h!=expected[k]: raise RuntimeError(f'{k}: SHA-256 mismatch: {h}; expected {expected[k]}')
  inputs[k]={'file':p.name,'bytes':p.stat().st_size,'sha256':h}
 out=args.out.resolve();out.mkdir(parents=True,exist_ok=False)
 commands=[]
 for label in ('ours','candidate'):
  cmd=[args.java,'-jar',str(paths['apktool']),'d','-r','--no-assets','-j','4','-p',str(out/'framework'),'-o',str(out/'decoded'/label),str(paths[label])]
  run=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,encoding='utf8',errors='replace')
  (out/f'decode-{label}.log').write_text(run.stdout,encoding='utf8')
  commands.append({'argv':cmd,'exit_code':run.returncode,'output':run.stdout})
  save(out/'execution.json',{'python':platform.python_version(),'inputs':inputs,'commands':commands})
  if run.returncode: raise RuntimeError(f'{label}: decode failed; see decode log')
 a=smali(out/'decoded'/'ours');b=smali(out/'decoded'/'candidate');rows=[];changed=[]
 for key in sorted(a.keys()|b.keys()):
  x=a.get(key);y=b.get(key)
  relation='identical' if x is not None and x==y else 'changed' if x is not None and y is not None else 'only_ours' if y is None else 'only_candidate'
  ratio=1.0 if relation=='identical' else None
  if relation=='changed':
   lx=x.decode('utf8').splitlines();ly=y.decode('utf8').splitlines()
   s=difflib.SequenceMatcher(None,lx,ly,autojunk=False);ratio=s.ratio()
   changed.append({'path':key,'similarity':ratio,'ours_lines':len(lx),'candidate_lines':len(ly),'hunks':[dict(tag=t,ours_start=i1+1,ours_end=i2,candidate_start=j1+1,candidate_end=j2) for t,i1,i2,j1,j2 in s.get_opcodes() if t!='equal']})
  rows.append({'path':key,'relation':relation,'ours_sha256':sha(x) if x is not None else '', 'candidate_sha256':sha(y) if y is not None else '', 'line_similarity':ratio})
 with (out/'smali-files.csv').open('w',encoding='utf-8-sig',newline='') as f:
  w=csv.DictWriter(f,fieldnames=rows[0].keys());w.writeheader();w.writerows(rows)
 save(out/'changed-classes.json',changed)
 for key in ['CNWebProxy.smali','CNPaths.smali','CNBuildConfig.smali']:
  diff=''.join(difflib.unified_diff(a[key].decode('utf8').splitlines(keepends=True),b[key].decode('utf8').splitlines(keepends=True),fromfile='ours/'+key,tofile='candidate/'+key))
  (out/(key+'.diff.txt')).write_text(diff,encoding='utf8')
 ma,na=members(paths['ours']);mb,nb=members(paths['candidate'])
 save(out/'ours-members.json',ma);save(out/'candidate-members.json',mb)
 save(out/'ours-native.json',na);save(out/'candidate-native.json',nb)
 common_assets=sorted(k for k in ma.keys()&mb.keys() if k.startswith('assets/'))
 same_assets=[k for k in common_assets if ma[k]['sha256']==mb[k]['sha256']]
 baseline=json.loads((HERE/'totentanz-members.json').read_text('utf8'))
 original=[k for k in same_assets if baseline['members'].get(k,{}).get('sha256')==ma[k]['sha256']]
 save(out/'assets-comparison.json',{'common':common_assets,'identical':same_assets,'also_original':original})
 native=[]
 with zipfile.ZipFile(paths['ours']) as za,zipfile.ZipFile(paths['candidate']) as zb:
  for k in sorted(na.keys()&nb.keys()):
   x=na[k];y=nb[k];xx=za.read(k);yy=zb.read(k)
   native.append({'path':k,'identical':x['sha256']==y['sha256'],'ours_dynsym_count':len(x['all_dynsym_names']),'candidate_dynsym_count':len(y['all_dynsym_names']),'candidate_dynsym_subset':set(y['all_dynsym_names'])<=set(x['all_dynsym_names']),'ours_defined_exports':len(x['defined_global_weak_exports']),'candidate_defined_exports':len(y['defined_global_weak_exports']),'defined_export_sets_equal':x['defined_global_weak_exports']==y['defined_global_weak_exports'],'ours_has_symtab':x['has_symtab'],'candidate_has_symtab':y['has_symtab'],'byte_differences':sum(c!=d for c,d in zip(xx,yy))+abs(len(xx)-len(yy))})
 save(out/'native-comparison.json',native)
 counts={'ours_count':len(a),'candidate_count':len(b),'common':len(a.keys()&b.keys()),'union':len(a.keys()|b.keys()),'identical':sum(r['relation']=='identical' for r in rows),'changed':len(changed),'changed_gte90':sum(c['similarity']>=.9 for c in changed),'only_candidate':len(b.keys()-a.keys()),'only_ours':len(a.keys()-b.keys()),'common_assets':len(common_assets),'identical_assets':len(same_assets),'identical_assets_also_original':len(original),'candidate_members':len(mb),'ours_members':len(ma)}
 expected_counts=json.loads((HERE/'expected-results.json').read_text('utf8'))['counts']
 summary={'inputs':inputs,'scope':PREFIX+'**/*.smali','similarity':'SequenceMatcher(ours.splitlines(), candidate.splitlines(), autojunk=False)','counts':counts,'expected_counts_match':counts==expected_counts,'native':native}
 save(out/'summary.json',summary)
 for k,p in paths.items():
  if file_sha(p)!=inputs[k]['sha256']: raise RuntimeError('Input changed during comparison: '+k)
 save(out/'verification.json',{'input_hashes_unchanged':True,'expected_counts_match':counts==expected_counts,'commands_exit_zero':all(c['exit_code']==0 for c in commands)})
 print(json.dumps(counts,ensure_ascii=False,indent=2))
 print('EXPECTED_COUNTS_MATCH='+str(counts==expected_counts))
 return 0 if counts==expected_counts else 2
if __name__=='__main__':
 try: sys.exit(main())
 except Exception as e: print(type(e).__name__+': '+str(e),file=sys.stderr);sys.exit(1)
